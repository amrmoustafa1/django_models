from django.apps import AppConfig


class PstConfig(AppConfig):
    name = 'PST'
