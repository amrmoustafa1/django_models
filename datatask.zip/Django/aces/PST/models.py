from django.db import models

# Create your models here.
class User(models.Model):
    Name=models.CharField(max_length=15)
    user_id=models.IntegerField()
    email=models.EmailField()
    def __str__(self):
      return self.Name
class Test(models.Model):
    q_id=models.IntegerField()
    q_marks=models.IntegerField()
    q_ans=models.BooleanField()
