#!c:\users\moustafa\desktop\django\python3\scripts\python.exe
from django.core import management

if __name__ == "__main__":
    management.execute_from_command_line()
